<div class="card shadow py-2">
    <div class="card-body">
    <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12 col-xlg-12 text-center" style="margin-bottom: 20px;">
                        <span class="db"><img witdh="250px" height="300px" src="<?=base_url('assets/')?>theme/assets/images/logo3.png" alt="logo" /></span>
                        <h1>Selamat Datang di Aplikasi E-Risalah Dewan DPRD Kota Blitar</h1>
                        </div>
                       
                    <div class="col-md-6 col-lg-4 col-xlg-4">
                   <a href="<?=base_url('rapat/tahun')?>">
                        <div class="card card-hover">
                            <div style="height: 160px;" class="box bg-warning text-center">

                                <h1 style="margin-top: 10px;" class="font-light text-white"><i class="far fa-handshake"></i></i></h1>
                                <h6 class="text-white">Jumlah Rapat Tahun <?= date('Y') ?></h6>
                                <h2 class="text-white"><?= $rapat[0]->total; ?></h2>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xlg-4">
                    <a href="<?=base_url('kunjungan/tahun')?>">
                        <div class="card card-hover">
                            <div style="height: 160px;" class="box bg-danger text-center">
                                <h1 style="margin-top: 10px;" class="font-light text-white"><i class="fas fa-fw fa-cubes"></i></h1>
                                <h6 class="text-white">Jumlah Kunjungan Kerja Tahun <?= date('Y') ?></h6>
                                <h2 class="text-white"><?= $kunker[0]->total; ?></h2>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xlg-4">
                    <a href="<?=base_url('sidak/sidaktahun')?>">
                        <div class="card card-hover">
                            <div style="height: 160px;" class="box bg-info text-center">

                                <h1 style="margin-top: 10px;" class="font-light text-white"><i class="fas fa-balance-scale"></i></h1>
                                <h6 class="text-white">Jumlah Tinjauan Lapangan Tahun <?= date('Y') ?></h6>
                                <h2 class="text-white"><?= $sidak[0]->total; ?></h2>
                            </div>
                        </div>
                        </a>
                    </div>
                  
                   
                </div>
    </div>
</div>