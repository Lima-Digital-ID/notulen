<div class="page-breadcrumb">
    <div class="row">
        <div class="col-md-5 align-self-center">
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Anggota</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?=$title?></li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="col-7 align-self-center">
            
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?=$title?></h4>
                    <?php echo form_open_multipart($action) ?>
                        <div class="form-group row" hidden>
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                ID Pegawai <?php echo form_error('id_pegawai') ?>
                            </label>
                            <div class="col-lg-6">
                                <input type="text" class="form-control" name="id_pegawai" id="id_pegawai" placeholder="ID Pegawai Auto Number" readonly="true" value="<?php echo $id_pegawai; ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                               Nama Anggota
                            </label>
                            <div class="col-lg-6">
                               <input type="text" class="form-control" name="nama_pegawai" id="nama_pegawai" placeholder="Nama Anngota" value="<?php echo $nama_pegawai; ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                               NIP
                            </label>
                            <div class="col-lg-6">
                               <input type="text" class="form-control" name="nip" id="nip" placeholder="NIP" value="<?php echo $nip; ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                               Prioritas
                            </label>
                            <div class="col-lg-6">
                               <input type="text" class="form-control" name="priority" id="priority" required placeholder="Prioritas" value="<?=$priority?>"/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Gender
                            </label>
                            <div class="col-lg-6">
                                <select name="jk" id="jk" class="form-control select2" style="width:100%" required>
                                    <option value="L" <?=$jk == 'L' ? 'selected' : ''?>>Laki-laki</option>
                                    <option value="P" <?=$jk == 'P' ? 'selected' : ''?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Kategori
                            </label>
                            <div class="col-lg-6">
                                <select name="tipe" id="tipe" class="form-control select2" style="width:100%" required  onchange="cekKategori()">
                                    <option value="1" <?=$tipe == 1 ? 'selected' : ''?>>Anggota Dewan</option>
                                    <option value="2" <?=$tipe == 2 ? 'selected' : ''?>>Forkopimda</option>
                                    <option value="3" <?=$tipe == 3 ? 'selected' : ''?>>Sekretaris Dewan</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Jenis Jabatan
                            </label>
                            <div class="col-lg-6">
                                <select name="jenis_jabatan" id="tipe" class="form-control select2" style="width:100%" required  onchange="cekKategori()">
                                    <option value="0" <?=$jenis_jabatan == 0 ? 'selected' : ''?>>--pilih jabatan--</option>
                                    <option value="1" <?=$jenis_jabatan == 1 ? 'selected' : ''?>>Eksekutif (Tanpa punya rapat sendiri)</option>
                                    <option value="2" <?=$jenis_jabatan == 2 ? 'selected' : ''?>>Pimpinan</option>
                                    <option value="3" <?=$jenis_jabatan == 3 ? 'selected' : ''?>>Badan Musyawarah (BANMUS)</option>
                                    <option value="4" <?=$jenis_jabatan == 4 ? 'selected' : ''?>>Badan Anggaran (BANGGAR)</option>
                                    <option value="5" <?=$jenis_jabatan == 5 ? 'selected' : ''?> >Badan Pembentuk Peraturan Daerah (BAMPERDA)</option>
                                    <option value="6" <?=$jenis_jabatan == 6 ? 'selected' : ''?>>Badan Kehormatan (BK)</option>
                                    <option value="7" <?=$jenis_jabatan == 7 ? 'selected' : ''?>>Sekretariat DPRD</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Upload Tanda Tangan
                            </label>
                            <div class="col-lg-6">
                            <?php 
                            //when edit
                                if(isset($infoTtd)){
                            ?>
                            <img src="<?php echo base_url()."assets/images/upload-ttd/".$ttd ?>" alt="" width="200px">
                            <br>
                            <?php } ?>
                                <?php echo isset($infoTtd) ? "<small style='color:red'>$infoTtd</small>" : "" ?>
                                <input type="file" name="ttd" class="form-control" id="">
                            </div>
                        </div>
                        <div class="form-group row" id="row_partai">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Partai
                            </label>
                            <div class="col-lg-6">
                                <select name="id_partai" id="id_partai" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddPartai" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row"  id="row_fraksi">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Fraksi
                            </label>
                            <div class="col-lg-6">
                                <select name="id_fraksi" id="id_fraksi" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddFraksi" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row" id="row_komisi">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Komisi
                            </label>
                            <div class="col-lg-6">
                                <select name="id_komisi" id="id_komisi" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddKomisi" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row" id="row_bamus">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Bamus
                            </label>
                            <div class="col-lg-6">
                                <select name="id_bamus" id="id_bamus" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddBamus" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row" id="row_banggar">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                Banggar
                            </label>
                            <div class="col-lg-6">
                                <select name="id_banggar" id="id_banggar" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddBanggar" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row" id="row_bk">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                                BK
                            </label>
                            <div class="col-lg-6">
                                <select name="id_bk" id="id_bk" class="form-control select2" style="width:100%">
                                </select>
                            </div>
                            <div class="col-lg-2">
                                <button type="button" class="btn btn-primary btn-sm" data-target="#modalAddBk" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 control-label text-lg-right pt-2">
                            </label>
                            <div class="col-lg-6">
                                    <button type="submit" class="btn btn-success"><i class="fa fa-floppy-o"></i> Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="modalAddPartai" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_partai" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Partai</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div id="modalAddFraksi" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_fraksi" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Fraksi</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div id="modalAddKomisi" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_komisi" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Komisi</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div id="modalAddBamus" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_bamus" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Bamus</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div id="modalAddBanggar" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_banggar" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Banggar</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div id="modalAddBk" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_bk" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Banggar</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" name="nama" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script src="<?=base_url('assets/')?>theme/assets/libs/jquery/dist/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $("form#form_partai").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_partai')?>", //json get site
                dataType : 'json',
                data: $('#form_partai').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddPartai').modal('hide');
            reloadPartaiOption();
        });
        $("form#form_fraksi").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_fraksi')?>", //json get site
                dataType : 'json',
                data: $('#form_fraksi').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddFraksi').modal('hide');
            reloadFraksiOption();
        });
        $("form#form_komisi").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_komisi')?>", //json get site
                dataType : 'json',
                data: $('#form_komisi').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddKomisi').modal('hide');
            reloadKomisiOption();
        });
        $("form#form_bamus").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_bamus')?>", //json get site
                dataType : 'json',
                data: $('#form_bamus').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddBamus').modal('hide');
            reloadBamusOption();
        });
        $("form#form_banggar").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_banggar')?>", //json get site
                dataType : 'json',
                data: $('#form_banggar').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddBanggar').modal('hide');
            reloadBanggarOption();
        });
        $("form#form_bk").on("submit", function( event ) {
            event.preventDefault();
            var response_data=null;
            $.ajax({
                type: "POST",
                url: "<?= base_url('welcome/add_bk')?>", //json get site
                dataType : 'json',
                data: $('#form_bk').serialize(),
                success: function(response){
                    response_data=response;
                }
            });
            $('#modalAddBk').modal('hide');
            reloadBkOption();
        });
        cekKategori();
    });
    function reloadPartaiOption(){
        var partai_option=$('#id_partai')
        partai_option.empty()
        partai_option.append('<option value="">Pilih Partai</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/partai_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        partai_option.append('<option '+(<?=$id_partai != null ? $id_partai : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function reloadFraksiOption(){
        var fraksi_option=$('#id_fraksi')
        fraksi_option.empty()
        fraksi_option.append('<option value="">Pilih Fraksi</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/fraksi_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        fraksi_option.append('<option '+(<?=$id_fraksi != null ? $id_fraksi : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function reloadKomisiOption(){
        var komisi_option=$('#id_komisi')
        komisi_option.empty()
        komisi_option.append('<option value="">Pilih Komisi</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/komisi_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        komisi_option.append('<option '+(<?=$id_komisi != null ? $id_komisi : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function reloadBamusOption(){
        var bamus_option=$('#id_bamus')
        bamus_option.empty()
        bamus_option.append('<option value="">Pilih Bamus</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/bamus_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        bamus_option.append('<option '+(<?=$id_bamus != null ? $id_bamus : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function reloadBanggarOption(){
        var banggar_option=$('#id_banggar')
        banggar_option.empty()
        banggar_option.append('<option value="">Pilih Banggar</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/banggar_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        banggar_option.append('<option '+(<?=$id_banggar != null ? $id_banggar : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function reloadBkOption(){
        var banggar_option=$('#id_bk')
        banggar_option.empty()
        banggar_option.append('<option value="">Pilih Bk</option>')
        $.ajax({
            type: "get",
            url: "<?= base_url('welcome/bk_option')?>", //json get site
            dataType : 'json',
            success: function(response){
                response_data=response['data'];
                if(response_data != null){
                    for(i=0; i < response_data.length; i++){
                        banggar_option.append('<option '+(<?=$id_bk != null ? $id_bk : 0?> == response_data[i]['id'] ? 'selected' : '')+' value="'+response_data[i]['id']+'">'+response_data[i]['nama']+'</option>')
                    }
                }
            }
        });
    }
    function cekKategori(){
        val=$('#tipe').val();
        if(val != 2){
            $('#row_partai').show();
            $('#row_fraksi').show();
            $('#row_komisi').show();
            $('#row_bamus').show();
            $('#row_banggar').show();
            $('#row_bk').show();
            reloadPartaiOption();
            reloadFraksiOption();
            reloadKomisiOption();
            reloadBamusOption();
            reloadBanggarOption();
            reloadBkOption();
        }else{
            $('#row_partai').hide();
            $('#row_fraksi').hide();
            $('#row_komisi').hide();
            $('#row_bamus').hide();
            $('#row_banggar').hide();
            $('#row_bk').hide();
            $('#id_partai').val('');
            $('#id_fraksi').val('');
            $('#id_komisi').val('');
            $('#id_bamus').val('');
            $('#id_banggar').val('');
            $('#id_bk').val('');
        }
    }
</script>
