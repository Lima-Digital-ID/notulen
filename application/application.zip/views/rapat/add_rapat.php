<div class="page-breadcrumb">
    <div class="row">
        <div class="col-md-5 align-self-center">
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Rapat</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Tambah</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="col-7 align-self-center">
            
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Tambah</h4>
                    <form class="mt-4" action="<?=base_url('rapat/save_rapat')?>" method="post" id="form_add" autocomplete="off" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Judul</label>
                            <input type="text" class="form-control" id="title" name="title" required autofocus>
                        </div>   
                        <div class="form-group">
                            <label>Tempat</label>
                            <input type="text" class="form-control" name="tempat">
                        </div>   
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label>Tanggal</label>
                                    <input type="text" class="form-control" id="tanggal" name="tanggal" placeholder="dd/mm/yyyy" >
                                </div> 
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label>Waktu</label>
                                    <input type="time" class="form-control" name="waktu" >
                                </div>   
                            </div>
                        </div>          
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">Sifat Rapat</label>
                                    <select name="sifat" id="sifat" class="form-control select2" style="width:100%">
                                        <option value="0">Tertutup</option>
                                        <option value="1">Terbuka</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">Jenis Rapat</label>
                                    <select name="tipe" id="tipe" class="form-control select2" style="width:100%">
                                    <?php 
                                        foreach (tipe() as $key => $value) {
                                            $key++;
                                            $dataSub = "";
                                            if(cekSub($key)){
                                                $dataSub = implode(',',subtipe($value));
                                            }
                                    ?>
                                    <option data-sub="<?php echo $dataSub ?>" data-value="<?php echo $value ?>" value="<?php echo $key ?>"><?php echo $value ?></option>
                                    <?php
                                        }
                                    ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6" id="submenu_komisi" style="display:none">
                                <div class="form-group">
                                    <label for="">Sub Menu Rapat Komisi</label>
                                    <select name="sub_menu_komisi" id="sub" class="form-control select2" style="width:100%;">
                                        <option value="0" selected>--Pilih--</option>
                                    </select>
                                    
                                </div>
                            </div>
                        </div>             
                        <div class="form-group">
                            <label for="">Materi Rapat</label>
                            <textarea name="event" id="ckeditor" cols="50" rows="15" class="ckeditor"></textarea>
                        </div>           
                        <div class="row">
                        <div class="col-md-5"><hr></div><div class="col-md-2"><center style="margin-top:5px"><h5>Peserta Rapat</h5></center></div><div class="col-md-5"><hr></div>
                        </div>
                        <br>
                        
                        <div class="row">
                            <div class="col-6">
                           
                                <label for="">Anggota DPRD</label>
                                <!-- <div class="form-group">
                                    <label for="">Anggota Dewan</label>
                                    <select name="id_anggota" id="id_anggota" class="form-control select2" style="width:100%">
                                    
                                    </select>
                                </div> -->
                                <div class="table-responsive">
                                    <table  class="table table-striped table-bordered">
                                        <thead id="row_anggota">
                                            
                                        </thead>
                                    </table>
                                </div>
                                <label for="">Sekretaris Dewan</label>
                                <div class="table-responsive">
                                    <table  class="table table-striped table-bordered">
                                        <thead id="row_sekwan">
                                            
                                        </thead>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="col-6" id="mitra" style="display:none">
                                <!-- <div class="form-group" id="row_forkopimda">
                                    <label for="">Forkopimda</label>
                                    <select name="formkopimda_id" id="formkopimda_id" class="form-control select2" style="width:100%">
                                    
                                    </select>
                                </div> -->
                                <label for="">Mitra Kerja</label>&nbsp;<button type="button" class="btn btn-primary btn-xs" data-target="#modalAddForkopimda" data-toggle="modal" style="margin-top:5px"><i class="fa fa-plus"></i></button>
                           
                                <div class="table-responsive">
                                    <table  class="table table-striped table-bordered">
                                        <thead id="row_forkopimda">
                                            
                                        </thead>
                                    </table>
                                </div>
                            </div>
                            <div class="col-6">
                        <!--    <div class="form-group">-->
                        <!--    <label for="">Galeri Rapat</label>-->
                        <!--    <input type="file" class="form-control" name="files[]" id="files" multiple=""  accept="application/pdf,application/vnd.ms-excel,image/*">-->
                        <!--</div>  -->
                                <!-- <div class="form-group" id="row_forkopimda">
                                    <label for="">Forkopimda</label>
                                    <select name="formkopimda_id" id="formkopimda_id" class="form-control select2" style="width:100%">
                                    
                                    </select>
                                </div> -->
                               
                                
                            </div>
                        </div>  
                        <br><br>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="modalAddForkopimda" class="modal fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form_forkopimda" action="javascript:;" accept-charset="utf-8" method="post" enctype="multipart/form-data">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Tambah Forkopimda</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="">Nama</label>
                    <input type="text" class="form-control" name="nama_pegawai" required>
                </div>
                <div class="form-group">
                    <label for="">Prioritas</label>
                    <input type="text" class="form-control" name="priority" required>
                </div>
                <div class="form-group">
                    <label for="">Gender</label>
                    <select name="jk" id="jk" class="form-control select2" style="width:100%" required>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <input type="hidden" class="form-control" name="tipe" value="2">
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success waves-effect">Simpan</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>
<script src="<?=base_url('assets/')?>theme/assets/libs/jquery/dist/jquery.min.js"></script>
<script src="<?=base_url('assets/')?>theme/assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url('assets/')?>theme/assets/libs/moment/moment.js"></script>
<script src="<?=base_url('assets/')?>theme/assets/libs/ckeditor/ckeditor.js"></script>
<script src="<?=base_url('assets/')?>theme/assets/libs/ckeditor/samples/js/sample.js"></script>
<script>
$('#tanggal').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
        todayHighlight: true
    });
$(document).ready(function(){
    anggotaOption();
    forkopimdaOption();
    sekwanOption();
    $("#tipe").change(function(){
        var thisVal = $(this).val()
        if(thisVal==2 || thisVal==4 || thisVal==6){
            $("#mitra").show()
        }
        else{
            $("#mitra").hide()
        }
        $("#submenu_komisi option").remove()
        if(thisVal==2 || thisVal==5 || thisVal==6){
            var dataSub = $(this).find(':selected').attr('data-sub').split(',')
            dataSub.forEach(function(data,key){
                key++
                $("#sub").append(`<option value='${key}'>${data}</option>`)
            })
            $("#submenu_komisi").show()
        }
        else{
            $("#submenu_komisi").hide()
        }        
    })
    $("#sub").change(function(){
      var tipe = $("#tipe").val()  
      var sub = $(this).val()

      if(tipe==6 && sub==1 || tipe==6 && sub==8 || tipe==2){
          $("#mitra").show()
      }
      else{
          $("#mitra").hide()
      }
    })
    $("form#form_forkopimda").on("submit", function( event ) {
        event.preventDefault();
        var response_data=null;
        $.ajax({
            type: "POST",
            url: "<?= base_url('welcome/add_anggota')?>", //json get site
            dataType : 'json',
            data: $('#form_forkopimda').serialize(),
            success: function(response){
                response_data=response;
                forkopimdaOption();
            }
        });
        $('#modalAddForkopimda').modal('hide');
        
    });
});

function anggotaOption(){
    // var id_anggota=$('#id_anggota')
    // id_anggota.empty()
    // id_anggota.append('<option value="">Pilih Anggota Dewan</option>')
    $('#row_anggota').empty()
    $.ajax({
        type: "get",
        url: "<?= base_url('pegawai/anggota_json/1')?>", //json get site
        dataType : 'json',
        success: function(response){
            response_data=response['data'];
            if(response_data != null){
                for(i=0; i < response_data.length; i++){
                    // id_anggota.append('<option value="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</option>')
                    $('#row_anggota').append('<tr><th class="text-center"width="10px"><input type="checkbox" value="'+response_data[i]['id_pegawai']+'" name="id_anggota[]"  id="'+response_data[i]['id_pegawai']+'"></th> <th class="text-center" width="300px"><label class="form-check-label" for="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</label></th></tr>')
                }
            }
        }
    });
}
function forkopimdaOption(){
    // var formkopimda_id=$('#formkopimda_id')
    // formkopimda_id.empty()
    // formkopimda_id.append('<option value="">Pilih Forkopimda</option>')
    $('#row_forkopimda').empty()
    $.ajax({
        type: "get",
        url: "<?= base_url('pegawai/anggota_json/2')?>", //json get site
        dataType : 'json',
        success: function(response){
            response_data=response['data'];
            if(response_data != null){
                for(i=0; i < response_data.length; i++){
                    // formkopimda_id.append('<option value="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</option>')
                    $('#row_forkopimda').append('<tr><th class="text-center"width="10px"><input type="checkbox" value="'+response_data[i]['id_pegawai']+'" name="id_anggota[]" id="'+response_data[i]['id_pegawai']+'"></th> <th class="text-center" width="300px"> <label class="form-check-label" for="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</label></th></tr>')
                }
            }
        }
    });
}
function sekwanOption(){
    // var formkopimda_id=$('#formkopimda_id')
    // formkopimda_id.empty()
    // formkopimda_id.append('<option value="">Pilih Sekretaris Dewan</option>')
    $('#row_sekwan').empty()
    $.ajax({
        type: "get",
        url: "<?= base_url('pegawai/anggota_json/3')?>", //json get site
        dataType : 'json',
        success: function(response){
            response_data=response['data'];
            if(response_data != null){
                for(i=0; i < response_data.length; i++){
                    // formkopimda_id.append('<option value="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</option>')
                    $('#row_sekwan').append('<tr><th class="text-center"width="10px"><input type="checkbox" value="'+response_data[i]['id_pegawai']+'" name="id_anggota[]" id="'+response_data[i]['id_pegawai']+'"></th> <th class="text-center" width="300px"> <label class="form-check-label" for="'+response_data[i]['id_pegawai']+'">'+response_data[i]['nama_pegawai']+'</label> </th></tr>')
                }
            }
        }
    });
}
</script>